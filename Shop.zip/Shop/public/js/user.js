function showUsers() {
    console.log('show all the users');

    const url = baseUrl_API + '/users';
    $.ajax({
        url: url,
        headers: {'Authorization': 'Bearer ${jwt}'}
    }).done(function (data) {
        displayUsers(data);
    }).fail(function (jqXHR, textStatus) {
        let error = {'code': jqXHR.staus,
            'status':jqXHR.responseJson.status};
        showMessage('Error', JSON.stringify(error, null, 4));
    });

}

function displayUsers(users) {
    let _html;
    _html = `<div class='content-row content-row-header'>
        <div class='user-name'>Name</div>
        <div class='user-email'>Email</div>
        <div class='user-profileicon-phone'>Profile Icon</div>
        <div class='user-username'>Username</div>
        </div>`;
    for (let x in users) {
        let user = users[x];
        let cssClass = (x % 2 == 0) ? 'content-row' : 'content-row content-row-odd';
        _html += `<div id='content-row-${user.id}' class='${cssClass}'>
            <div class='user-name'>
                <span class='list-key' data-user='${user.id}' 
                     onclick=showUserPostsPreview('${user.id}') 
                     title='Get messages made by the user'>${user.name}
                </span>
            </div>
            <div class='user-email'>${user.email}</div>
            <div class='user-profileicon'>${user.profile_icon}</div>
            <div class='user-username'>${user.username}</div>            
            </div>`;
    }

    updateMain('Users', 'All Users', _html);
}





