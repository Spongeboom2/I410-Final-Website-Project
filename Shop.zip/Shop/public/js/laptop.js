// Pagination, sorting, and limiting are disabled

function showLaptops(offset = 0) {
        console.log('show all laptops');

        //if the selection list exists, retrieve the selected option value; otherwise, set a default value.
        let limit = ($("#post-limit-select").length) ? $('#post-limit-select option:checked').val() : 5;
        let sort = ($("#post-sort-select").length) ? $('#post-sort-select option:checked').val() : "id:asc";

        //construct the request url
        const url = baseUrl_API + '/laptops?limit=' + limit + "&offset=" + offset + "&sort=" + sort;
        console.log(url);
//define AXIOS request
    axios({
        method: 'get',
        url: url,
        cache: true,
        headers: {"Authorization": "Bearer " + jwt}
    })
        .then(function (response) {
            displayLaptops(response.data);
        })
        .catch(function (error) {
            handleAxiosError(error);
        });
}

//Callback function: display all posts; The parameter is a promise returned by axios request.
function displayLaptops (response) {
    //console.log(response);
    let _html;
    _html =
        "<div class='content-row content-row-header'>" +
        "<div class='laptop-id'>Laptop ID</></div>" +
        "<div class='laptop-body'>Laptop Body</></div>" +
        "<div class='laptop-create'>Create Time</div>" +
        "<div class='laptop-update'>Update Time</div>" +
        "</div>";

    let laptops = response.data;
    laptops.forEach(function(laptop, x){
        let cssClass = (x % 2 == 0) ? 'content-row' : 'content-row content-row-odd';
        _html += "<div class='" + cssClass + "'>" +
            "<div class='laptop-id'>" +
            "<span class='list-key' onclick=showLaptops('" + laptop.id + "') title='Get laptop details'>" + laptop.id + "</span>" +
            "</div>" +
            "<div class='laptop-body'>" + laptop.body + "</div>" +
            "<div class='laptop-create'>" + laptop.created_at + "</div>" +
            "<div class='laptop-update'>" + laptop.updated_at + "</div>" +
            "</div>" +
            "<div class='container laptop-detail' id='laptop-detail-" + laptop.id + "' style='display: none'></div>";
    });

    _html += "<div class='content-row course-pagination'><div>";
    //pagination
    _html += paginateLaptops(response);
    //items per page
    _html += limitLaptops(response);
    //sorting
    _html += sortLaptops(response);
    //end the div block
    _html += "</div></div>";

    //Finally, update the page
    updateMain('laptops', 'All laptops', _html);
}


/***********************************************************************************************************
 ******                            Show Comments made for a message                                   ******
 **********************************************************************************************************/
/* Display all comments. It get called when a user clicks on a message's id number in
 * the message list. The parameter is the message id number.
*/
function showBrands(number) {
    console.log('get a laptop\'s all brands');
    let url = baseUrl_API + '/laptops/' + number + '/brands';
    axios({
        method: 'get',
        url: url,
        cache: true,
        headers: {"Authorization": "Bearer " + jwt}
    })
        .then(function (response) {
//console.log(response.data);
            displayBrands(number, response);
        })
        .catch(function (error) {
            handleAxiosError(error);
        });

}


// Callback function that displays all details of a course.
// Parameters: course number, a promise
function displayBrands(number, response) {
    let _html = "<div class='content-row content-row-header'>Comments</div>";
    let brands = response.data;
    //console.log(number);
    //console.log(comments);
    brands.forEach(function(brand, x){
        _html +=
            "<div class='brand-detail-row'><div class='brand-detail-label'>Brand ID</div><div class='brand-detail-field'>" + brand.id + "</div></div>" +
            "<div class='brand-detail-row'><div class='brand-detail-label'>Brand Body</div><div class='brand-detail-field'>" + brand.body + "</div></div>" +
            "<div class='brand-detail-row'><div class='brand-detail-label'>Create Time</div><div class='brand-detail-field'>" + brand.created_at + "</div></div>";
    });

    $('#brand-detail-' + number).html(_html);
    $("[id^='brand-detail-']").each(function(){   //hide the visible one
        $(this).not("[id*='" + number + "']").hide();
    });

    $('#brand-detail-' + number).toggle();
}

function handleAxiosError(error) {
    let errMessage;
    if (error.response) {
// The request was made and the server responded with a status code of 4xx or 5xx
        errMessage = {"Code": error.response.status, "Status":
            error.response.data.status};
    } else if (error.request) {
// The request was made but no response was received
        errMessage = {"Code": error.request.status, "Status":
            error.request.data.status};
    } else {
// Something happened in setting up the request that triggered an
        error
        errMessage = JSON.stringify(error.message, null, 4);
    }
    showMessage('Error', errMessage);
}

//paginate all messages
function paginateLaptops(response) {
//calculate the total number of pages
    let limit = response.limit;
    let totalCount = response.totalCount;
    let totalPages = Math.ceil(totalCount / limit);
//determine the current page showing
    let offset = response.offset;
    let currentPage = offset / limit + 1;
//retrieve the array of links from response json
    let links = response.links;
//convert an array of links to JSON document. Keys are "self", "prev", "next", "first", "last"; values are offsets.
        let pages = {};
//extract offset from each link and store it in pages
    links.forEach(function (link) {
        let href = link.href;
        let offset = href.substr(href.indexOf('offset') + 7);
        pages[link.rel] = offset;
    });
    if (!pages.hasOwnProperty('prev')) {
        pages.prev = pages.self;
    }
    if (!pages.hasOwnProperty('next')) {
        pages.next = pages.self;
    }
//generate HTML code for links
    let _html = `Showing Page ${currentPage} of
${totalPages}&nbsp;&nbsp;&nbsp;&nbsp;
<a href='#course' title="first page"
onclick='showLaptops(${pages.first})'> << </a>
<a href='#course' title="previous page"
onclick='showLaptops(${pages.prev})'> < </a>
<a href='#course' title="next page"
onclick='showLaptops(${pages.next})'> > </a>
<a href='#course' title="last page"
onclick='showLaptops(${pages.last})'> >> </a>`;
    return _html;
}

//limit messages
function limitLaptops(response) {
//define an array of courses per page options
    let postsPerPageOptions = [5, 10, 20];
//create a selection list for limiting courses
    let _html = `&nbsp;&nbsp;&nbsp;&nbsp; Items per page:<select id='laptop-limitselect' onChange='showLaptops()'>`;
    postsPerPageOptions.forEach(function (option) {
        let selected = (response.limit == option) ? "selected" : "";
        _html += `<option ${selected} value="${option}">${option}</option>`;
    });
    _html += "</select>";
    return _html;
}
//sort messages
function sortLaptops(response) {
//create selection list for sorting
    let sort = response.sort;
//sort field and direction: convert json to a string then remove {, }, and "
    let sortString = JSON.stringify(sort).replace(/["{}]+/g, "");
    console.log(sortString);
//define a JSON containing sort options
    let sortOptions = {
        "id:asc": "First Laptop ID -> Last Laptop ID",
        "id:desc": "Last Laptop ID -> First Laptop ID",
        "body:asc": "Laptop body A -> Z",
        "body:desc": "Laptop body Z -> A"
    };
//create the selection list
    let _html = "&nbsp;&nbsp;&nbsp;&nbsp; Sort by: <select id='laptop-sortselect'" + "onChange='showLaptops()'>";
    for (let option in sortOptions) {
        let selected = (option == sortString) ? "selected" : "";
        _html += `<option ${selected} value='${option}'>${sortOptions[option]}
</option>`;
    }
    _html += "</select>";
    return _html;
}

