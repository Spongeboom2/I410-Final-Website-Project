
//This function gets called when the Admin link in the nav bar is clicked. It shows all the records of messages
function showAllBrands() {
	console.log('Show all brands for admin.');

    const url = baseUrl_API + "/brands?limit=50";
    fetch(url, {
        method: 'GET',
        headers: {"Authorization": "Bearer " + jwt}
    })
        .then(checkFetch)
        .then(response => response.json())
        .then(brands => displayAllBrands(brands.data))
        .catch(err => showBrands("Errors", err)) //display errors
}

function displayAllBrands(Brandss, subheading=null) {
    console.log("display all brands for the editing purpose")

    // search box and the row of headings
    let _html = `<div style='text-align: right; margin-bottom: 3px'>
            <input id='search-term' placeholder='Enter search terms'> 
            <div class='content-row content-row-header'>
            <div class ='brand-name'> Brand Name</div>
            <div class='brand-id'>Brand ID</div>

            </div>`;  //end the row

    // content rows
    for (let x in brands) {
        let brand = brands[x];
        _html += `<div class='content-row'>
            <div class='brand-id'>${brand.BrandID}</div>
            <div class='brand-create' id='brand-edit-created_at-${brand.BrandID}'>${brand.BrandName}</div>`;

            _html += `<div class='list-edit'><button id='btn-brand-edit-${brand.BrandID}' onclick=editBrand('${brand.BrandID}') class='btn-light'> Edit </button></div>
            <div class='list-update'><button id='btn-brand-update-${brand.BrandID}' onclick=updateBrand('${brand.BrandID}') class='btn-light btn-update' style='display:none'> Update </button></div>
            <div class='list-delete'><button id='btn-brand-delete-${brand.BrandID}' onclick=deleteBrand('${brand.BrandID}') class='btn-light'>Delete</button></div>
            <div class='list-cancel'><button id='btn-brand-cancel-${brand.BrandID}' onclick=cancelUpdateBrand('${brand.BrandID}') class='btn-light btn-cancel' style='display:none'>Cancel</button></div>`

        _html += '</div>';  //end the row
    }

    //the row of element for adding a new brand

        _html += `<div class='content-row' id='brand-add-row' style='display: none'> 
            <div class='brand-id brand-editable' id='brand-new-user_id' contenteditable='true' content="Brand ID"></div>
            <div class='brand-body brand-editable' id='brand-new-body' contenteditable='true'></div>
            <div class='list-update'><button id='btn-add-brand-insert' onclick='addBrand()' class='btn-light btn-update'> Insert </button></div>
            <div class='list-cancel'><button id='btn-add-brand-cancel' onclick='cancelAddBrand()' class='btn-light btn-cancel'>Cancel</button></div>
            </div>`;  //end the row

        // add new brand button
        _html += `<div class='content-row brand-add-button-row'><div class='brand-add-button' onclick='showAddRow()'>+ ADD A NEW BRAND</div></div>`;

    //Finally, update the page
    subheading = (subheading == null) ? 'All Brands' : subheading;
    updateMain('Brands', subheading, _html);
}


// This function gets called when a user clicks on the Edit button to make items editable
function editBrand(id) {
    //Reset all items
    resetBrand();


    $("div#brand-brand-body-" + id).attr('contenteditable', true).addClass('brand-editable');
    $("div#brand-brand-image_url-" + id).attr('contenteditable', true).addClass('brand-editable');
    $("div#brand-brand-created_at-" + id).attr('contenteditable', true).addClass('brand-editable');
    $("div#brand-brand-updated_at-" + id).attr('contenteditable', true).addClass('brand-editable');

    $("button#btn-brand-edit-" + id + ", button#btn-brand-delete-" + id).hide();
    $("button#btn-brand-update-" + id + ", button#btn-brand-cancel-" + id).show();
    $("div#brand-add-row").hide();
}

//This function gets called when the user clicks on the Update button to update a message record
function updateBrand(id) {
	console.log('update the brand that the id is ' + id);

    let data = {};
    data['BrandName'] = $("div#brand-edit-BrandName-" + id).html();
    console.log(data);
    const url = baseUrl_API + "/brands/" + id;
    console.log(url);
    fetch(url, {
        method: 'PATCH',
        headers: {
            "Authorization": "Bearer " + jwt,
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
        .then(checkFetch)
        .then(() => resetBrands())
        .catch(error => showBrands("Errors", error))
}


//This function gets called when the user clicks on the Cancel button to cancel updating a message
function cancelUpdateBrand(id) {
    showAllBrands();
}


// delete
function deleteBrand(id) {
    $('#modal-button-ok').html("Delete").show().off('click').click(function () {
        removeBrand(id);
    });
    $('#modal-button-close').html('Cancel').show().off('click');
    $('#modal-title').html("Warning:");
    $('#modal-content').html('Are you sure you want to delete the brand?');

    // Display the modal
    $('#modal-center').modal();
}

function removeBrand(id) {
	console.log('remove the brand whose id is ' + id);

    let url = baseUrl_API + "/brands/" + id;
    fetch(url, {
        method: 'DElETE',
        headers: {"Authorization": "Bearer " + jwt,},
    })
        .then(checkFetch)
        .then(() => showAllBrands())
        .catch(error => showMessage("Errors", error))
}


function showAddRow() {
    resetBrand(); //Reset all items
    $('div#brand-add-row').show();
}

//This function inserts a new message. It gets called when a user clicks on the Insert button.
function addBrand() {
	console.log('Add a new brand');

    let data = {};
    $("div[id^='brand-new-']").each(function () {
        let field = $(this).attr('id').substr(9);
        let value = $(this).html();
        data[field] = value;
    });
    console.log(data);
    const url = baseUrl_API + "/brands";
    console.log(url);
    fetch(url, {
        method: 'POST',
        headers: {
            "Authorization": "Bearer " + jwt,
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
        .then(checkFetch)
        .then(() => showAllBrands())
        .catch(err => showBrands("Errors", err))
}



// This function cancels adding a new message. It gets called when a user clicks on the Cancel button.
function cancelAddBrand() {
    $('#brand-add-row').hide();
}

let checkFetch = async function (response) {
    if (!response.ok) {
        await response.json()  //need to use await so Javascipt will until promise settles and returns its result
            .then(result => {
                throw Error(JSON.stringify(result, null, 4));
            });
    }
    return response;
}

function resetBrand() {
    // Remove the editable feature from all divs
    $("div[id^='brand-edit-']").each(function () {
        $(this).removeAttr('contenteditable').removeClass('brand-editable');
    });

    // Hide all the update and cancel buttons and display all the edit and delete buttons
    $("button[id^='btn-brand-']").each(function () {
        const id = $(this).attr('id');
        if (id.indexOf('update') >= 0 || id.indexOf('cancel') >= 0) {
            $(this).hide();
        } else if (id.indexOf('edit') >= 0 || id.indexOf('delete') >= 0) {
            $(this).show();
        }
    });
}