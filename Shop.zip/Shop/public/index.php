<?php
// require __DIR__ . '/../config/bootstrap.php';
//echo $_SERVER['DOCUMENT_ROOT'];

require __DIR__ . '/../app/header.php';
require __DIR__ . '/../app/signin.php';
require __DIR__ . '/../app/signup.php';
require __DIR__ . '/../app/main.php';
require __DIR__ . '/../app/footer.php';
require __DIR__ . '/../app/modal.php';
