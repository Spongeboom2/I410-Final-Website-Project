<!--   Begin footer -------------->
<footer class="footer mt-auto py-3">
    <div class="container">
        <span class="text-muted"></span>
    </div>
</footer>
<!--<div id="loading" class="loading">
    Please wait while data are being retrieved.<img src="img/loading.gif">
</div>-->
<!-- JavaScript libraries -->
<!-- jQuery first, then Popper.js, then Bootstrap JS, then bootstrap-confirmation -->
<script src="../public/js/lib/jquery-3.5.1.min.js"></script>
<script src="../public/js/lib/popper-1.14.7.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="../public/js/lib/bootstrap-4.3.1.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
<script src="../public/js/lib/axios.min.js"></script>


<script src="../public/js/admin.js"></script>
<script src="../public/js/user.js"></script>
<script src="../public/js/signin.js"></script>
<script src="../public/js/signup.js"></script>
<script src="../public/js/signout.js"></script>
<script src="../public/js/index.js"></script>
<script src="../public/js/message.js"></script>
<script src="../public/js/post.js"></script>
</body>
</html>