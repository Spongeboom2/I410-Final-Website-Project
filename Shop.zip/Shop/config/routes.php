<?php


use Shop\Middleware\Logging as ShopLogging;
use Shop\Authentication\MyAuthenticator;
use Shop\Authentication\BasicAuthenticator;
use Shop\Authentication\BearerAuthenticator;
use Shop\Authentication\JWTAuthenticator;

$app->get('/', function ($request, $response, $args) {
    return $response->write('Welcome to our shop!');
});

$app->get('/hello/{name}', function ($request, $response, $args) {
    return $response->write("Hello " . $args['name']);
});


// User routes
$app->group('/users', function () {
    $this->get('', 'UserController:index');
    $this->get('/{id}', 'UserController:view');

    $this->post('', 'UserController:create');
    $this->put('/{id}', 'UserController:update');
    $this->patch('/{id}', 'UserController:update');
    $this->delete('/{id}', 'UserController:delete');

    $this->post('/authBearer', 'UserController:authBearer');
    $this->post('/authJWT', 'UserController:authJWT');


});

// Route groups
$app->group('', function () {
    $this->group('/brands', function () {
        // The Brands group
        $this->get('', 'brandsController:index');
        $this->get('/{BrandID}', 'brandsController:view');

        $this->post('', 'brandController:create');
        $this->put('/{BrandID}', 'brandController:update');
        $this->patch('/{BrandID}', 'brandController:update');
        $this->delete('/{BrandID}', 'brandController:delete');

    });

    // The Desktop group
    $this->group('/desktops', function () {
        $this->get('', 'desktopsController:index'); // "Class" is registered in DIC
        $this->get('/{DesktopID}', 'desktopsController:view');

        $this->post('', 'desktopsController:create');
        $this->put('/{id}', 'desktopsController:update');
        $this->patch('/{id}', 'desktopsController:update');
        $this->delete('/{id}', 'desktopsController:delete');

    });

    //Other Groups still need to be added, use Desktop as an exmaple.

    //laptops
    $this->group('/laptops', function () {
        $this->get('', 'laptopsController:index');

        /** You're searching with the INDEX and VIEW Controllers.
         * You don't need new ones
        $this->get('/laptops', 'laptops:pagination');
        $this->get('/laptops', 'laptops:sorting');
        $this->get('/laptops', 'laptops:search');
         */

        $this->get('/{LaptopID}', 'laptopsController:view');
        $this->post('', 'laptopsController:create');
        $this->put('/{LaptopID}', 'desktopsController:update');
        $this->patch('/{LaptopID}', 'desktopsController:update');
        $this->delete('/{LaptopID}', 'desktopsController:delete');
    });

    // mobile devices
    $this->group('/mobile_devices', function () {
        $this->get('', 'mobile_devicesController:index'); // "Class" is registered in DIC
        $this->get('/{id}', 'mobile_devicesController:view');

        $this->post('', 'mobile_devicesController:create');
        $this->put('/{id}', 'mobile_devicesController:update');
        $this->patch('/{id}', 'mobile_devicesController:update');
        $this->delete('/{id}', 'mobile_devicesController:delete');

    });

    // smartwatch devices
    $this->group('/smart_watches', function () {
        $this->get('', 'smart_watchesController:index'); // "Class" is registered in DIC
        $this->get('/{id}', 'smart_watchesController:view');

        $this->post('', 'smart_watchesController:create');
        $this->put('/{id}', 'smart_watchesController:update');
        $this->patch('/{id}', 'smart_watchesController:update');
        $this->delete('/{id}', 'smart_watchesController:delete');

    });

    // smart watch devices
    $this->group('/tablets', function () {
        $this->get('', 'tabletsController:index'); // "Class" is registered in DIC
        $this->get('/{id}', 'tabletsController:view');

        $this->post('', 'tabletsController:create');
        $this->put('/{id}', 'tabletsController:update');
        $this->patch('/{id}', 'tabletsController:update');
        $this->delete('/{id}', 'tabletsController:delete');

    });

//Commented out as they break when used with JWT
//})->add(new BearerAuthenticator());
//$app->add(new MyAuthenticator());
//$app->add(new BasicAuthenticator());

})->add(new JWTAuthenticator()); // this was used.


$app->add(new ShopLogging());
$app->run();