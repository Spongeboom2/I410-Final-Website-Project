<?php

$db_host = 'localhost';
$db_name = "electronics";
$db_user = "root";
$db_pass = "";
