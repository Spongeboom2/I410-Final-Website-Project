<?php


// Alias to the controllers
use Shop\Controllers\brandsController as brandsController;
use Shop\Controllers\desktopsController as desktopsController;
use Shop\Controllers\laptopsController as laptopsController;
use Shop\Controllers\mobile_devicesController as mobileController;
use Shop\Controllers\smart_watchesController as smartController;
use Shop\Controllers\tabletsController as tabletsController;
use Shop\Controllers\UserController as UserController;


$container['brandsController'] = function ($c) {
    return new brandsController();
};

$container['desktopsController'] = function ($c) {
    return new desktopsController();
};

$container['laptopsController'] = function ($c) {
    return new laptopsController();
};

$container['mobileController'] = function ($c) {
    return new mobileController();
};

$container['smartController'] = function ($c) {
    return new smartController();
};

$container['tabletsController'] = function ($c) {
    return new tabletsController();
};

$container['UserController'] = function ($c) {
    return new UserController();
};
