<?php

require __DIR__ . '/../config/bootstrap.php';
//echo $_SERVER['DOCUMENT_ROOT'];
