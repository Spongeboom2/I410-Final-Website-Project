<?php

require __DIR__ . '/../config/bootstrap.php';
//echo $_SERVER['DOCUMENT_ROOT'];


/* Ignore this but keep it - Parker


require __DIR__ . '/vendor/autoload.php';
require __DIR__ . "/bootstrap.php";

use Shop\Models\brands;
use Shop\Models\laptops;
use Shop\Models\desktops;
use Shop\Models\mobile_devices;
use Shop\Models\smart_watches;
use Shop\Models\tablets;


$app->get('/', function($request, $response, $args){
    return $response->write("Hello, this is Corporate Electronic Emporium!");
});

//Brands
$app->get('/brands', function($request, $response, array $args){

    $brands = brands::all();

    $payload = [];

    foreach($brands as $Brand){
        $payload[$Brand->BrandID] = [
            "BrandID" => $Brand->BrandID,
            "BrandName" => $Brand->BrandName,

        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/brands/{BrandID}', function($request, $response, array $args){
    $id = $args['BrandID'];
    $brands = new brands();
    $_brand = $brands->find($id);

    $payload[$_brand->BrandID] = [
        "BrandID" => $_brand->BrandID,
        "BrandName" => $_brand->BrandName,

    ];
    return $response->withStatus(200)->withJson($payload);
});

$app->post('/brands', function ($request, $response, $args) {
    $brands = new brands();

    $_brand_id = $request->getParsedBodyParam('BrandID');
    $_brand = $request->getParsedBodyParam('BrandName');
    $brands->brand_id = $_brand_id;
    $brands->brand = $_brand;
    $brands->save();

    if ($brands->id) {
        $payload = ['brand_id' => $brands->id,
            'brands_uri' => '/brands/' . $brands->id];
        return $response->withStatus(201)->withJson($payload);
    } else {
        return $response->withStatus(500);
    }
});

$app->patch('/brands/{BrandID}', function ($request, $response, $args) {
    $id = $args['BrandID'];
    $brands = brands::findOrFail($id);

    $params = $request->getParsedBody();

    foreach ($params as $field => $value) {
        $brands->$field = $value;
    }
    $brands->save();

    if ($brands->id) {
        $payload = ['BrandID' => $brands->BrandID,
            'BrandName' => $brands->BrandName,
            'brands_uri' => '/brands/' . $brands->BrandID
        ];
        return $response->withStatus(200)-withJson($payload);
    } else {
        return $response->withStatus(500);
    }
});

$app->delete('/brands/{BrandID}', function ($request, $response, $args) {
    $id = $args['id'];
    $brands = brands::find($id);
    $brands->delete();

    if ($brands->exits) {
        return $response->withStatus(500);
    } else {
        return $response->withStatus(204)->getBody()->write("Brand'/brands/$id' has been deleted.");
    }
});


//Laptops
$app->get('/laptops', function($request, $response, array $args){

    $laptops = laptops::all();

    $payload = [];

    foreach($laptops as $laptop){
        $payload[$laptop->LaptopID] = [
            "LaptopID" => $laptop->LaptopID,
            "Brand" => $laptop->BrandID,
            "Price" => $laptop->Price,
            "model"=> $laptop->model,
            'warranty' => $laptop->warranty
        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/laptops/{LaptopID}', function($request, $response, array $args){
    $id = $args['LaptopID'];
    $laptops = new laptops();
    $_lap = $laptops->find($id);

    $payload[$_lap->LaptopID] = [
        "LaptopID" => $_lap->ID,
        "BrandID" => $_lap->Brand,
        "Price" => $_lap->Price,
        "Warranty" => $_lap->Warranty,
        "Model" => $_lap->Model
    ];
    return $response->withStatus(200)->withJson($payload);
});

//Desktops
$app->get('/desktops', function($request, $response, array $args){

    $desktops = desktops::all();

    $payload = [];

    foreach($desktops as $Desktop){
        $payload[$Desktop->DesktopID] = [
            "DesktopID" => $Desktop->DesktopID,
            "BrandID" => $Desktop->BrandID,
            "Price" => $Desktop->Price,
            "model"=>$Desktop->model,
            'warranty' => $Desktop->warranty
        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/desktops/{DesktopID}', function($request, $response, array $args){
    $id = $args['DesktopID'];
    $desktops = new desktops();
    $_desk = $desktops->find($id);

    $payload[$_desk->DesktopID] = [
        "DesktopID" => $_desk->DesktopID,
        "BrandID" => $_desk->BrandID,
        "Price" => $_desk->Price,
        "model" => $_desk->model,
        "warranty" => $_desk->warranty
    ];
    return $response->withStatus(200)->withJson($payload);
});

//mobiles
$app->get('/mobile', function($request, $response, array $args){

    $mobiles = mobile_devices::all();

    $payload = [];

    foreach($mobiles as $Mobile){
        $payload[$Mobile->MobileID] = [
            "MobileID" => $Mobile->MobileID,
            "BrandID" => $Mobile->BrandID,
            "Price" => $Mobile->Price,
            "Version"=>$Mobile->Version,
            'Warranty' => $Mobile->Warranty
        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/mobile/{MobileID}', function($request, $response, array $args){
    $id = $args['MobileID'];
    $mobiles = new mobile_devices();
    $_Mobile = $mobiles->find($id);

    $payload[$_Mobile->MobileID] = [
        "MobileID" => $_Mobile->MobileID,
        "BrandID" => $_Mobile->BrandID,
        "Price" => $_Mobile->Price,
        "Version"=>$_Mobile->Version,
        'Warranty' => $_Mobile->Warranty
    ];
    return $response->withStatus(200)->withJson($payload);
});

// Tablets

$app->get('/tablets', function($request, $response, array $args){

    $tablets = tablets::all();

    $payload = [];

    foreach($tablets as $Tablet){
        $payload[$Tablet->TabletID] = [
            "TabletID" => $Tablet->TabletID,
            "BrandID" => $Tablet->BrandID,
            "Version"=>$Tablet->Version,
            'Warranty' => $Tablet->Warranty,
            "Price" => $Tablet->Price
        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/tablets/{TabletID}', function($request, $response, array $args){
    $id = $args['TabletID'];
    $tablets = new tablets();
    $_Tablet = $tablets->find($id);

    $payload[$_Tablet->TabletID] = [
        "TabletID" => $_Tablet->TabletID,
        "BrandID" => $_Tablet->BrandID,
        "Version"=>$_Tablet->Version,
        'Warranty' => $_Tablet->Warranty,
        "Price" => $_Tablet->Price
    ];
    return $response->withStatus(200)->withJson($payload);
});

// Smart Watches

$app->get('/smart_watches', function($request, $response, array $args){

    $watches = smart_watches::all();

    $payload = [];

    foreach($watches as $Watch){
        $payload[$Watch->WatchID] = [
            "WatchID" => $Watch->WatchID,
            "BrandID" => $Watch->BrandID,
            "Version"=>$Watch->Version,
            'Warranty' => $Watch->Warranty,
            "Price" => $Watch->Price
        ];
    }
    return $response->withStatus(200)->withJson($payload);
});

$app->get('/smart_watches/{WatchID}', function($request, $response, array $args){
    $id = $args['WatchID'];
    $watches = new watches();
    $_Watch = $watches->find($id);

    $payload[$_Watch->WatchID] = [
        "WatchID" => $_Watch->WatchID,
        "BrandID" => $_Watch->BrandID,
        "Version"=>$_Watch->Version,
        'Warranty' => $_Watch->Warranty,
        "Price" => $_Watch->Price
    ];
    return $response->withStatus(200)->withJson($payload);
});


$app->run();