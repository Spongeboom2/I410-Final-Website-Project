<?php


namespace Shop\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\smart_watches;

class smart_watchesController
{

    //list all  with pagination, sort, search by query features
    public function index(Request $request, Response $response, array $args)
    {
        $results = smart_watches::getSmart($request);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    //view id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['WatchID'];
        $results = smart_watches:: getSmartById($id);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Create
    public function create(Request $request, Response $response, array $args)
    {
        // Insert
        $smart = smart_watches::createSmart($request);
        if ($smart->id) {
            $results = [
                'status' => 'smart Watch created',
                'mobile_uri' => '/smart_watch/' . $smart->id,
                'data' => $smart
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update
    public function update(Request $request, Response $response, array $args)
    {
        // Insert
        $smart = smart_watches::updateSmart($request);
        if ($smart->id) {
            $results = [
                'status' => 'smart watch created',
                'smart_uri' => '/smart_watch/' . $smart->id,
                'data' => $smart
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('WatchID');
        smart_watches::deleteSmart($request);
        if (smart_watches::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "smart '/smart_watches/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }
}
