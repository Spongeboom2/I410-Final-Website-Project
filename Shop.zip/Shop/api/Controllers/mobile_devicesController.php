<?php


namespace Shop\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\mobile_devices;

class mobile_devicesController
{

    //list all  with pagination, sort, search by query features
    public function index(Request $request, Response $response, array $args)
    {
        $results = mobile_devices::getMobile($request);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    //view id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['MobileID'];
        $results = mobile_devices:: getMobileById($id);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Create
    public function create(Request $request, Response $response, array $args)
    {
        // Insert a new desktop
        $Mobile = mobile_devices::createMobile($request);
        if ($Mobile->id) {
            $results = [
                'status' => 'mobile device created',
                'mobile_uri' => '/mobile/' . $Mobile->id,
                'data' => $Mobile
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update
    public function update(Request $request, Response $response, array $args)
    {
        // Insert
        $mobile = mobile_devices::updateMobile($request);
        if ($mobile->id) {
            $results = [
                'status' => 'mobile device created',
                'mobile_uri' => '/mobiles/' . $mobile->id,
                'data' => $mobile
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('MobileID');
        mobile_devices::deleteMobile($request);
        if (mobile_devices::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "Mobile '/Mobiles/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }
}
