<?php


namespace Shop\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\laptops;

class laptopsController
{

    //list all laptops with pagination, sort, search by query features
    public function index(Request $request, Response $response, array $args)
    {
        $results = laptops::getLaptop($request);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    //view a desktop by id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['LaptopID'];
        $results = laptops:: getLaptopById($id);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Create a laptop
    public function create(Request $request, Response $response, array $args)
    {
        // Insert a new desktop
        $laptop = laptops::createLaptop($request);
        if ($laptop->id) {
            $results = [
                'status' => 'Laptop created',
                'laptop_uri' => '/laptops/' . $laptop->id,
                'data' => $laptop
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update a desktop
    public function update(Request $request, Response $response, array $args)
    {
        // Insert a new laptop
        $laptop = laptops::updateLaptop($request);
        if ($laptop->id) {
            $results = [
                'status' => 'Laptop created',
                'laptop_uri' => '/laptops/' . $laptop->id,
                'data' => $laptop
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete a laptop
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('LaptopID');
        laptops::deleteLaptop($request);
        if (laptops::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "Laptop '/laptops/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }

    /** This Does not belong here, it needs to be in laptops.php

    public function pagination ($request, $response, $args)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        $links = laptops::getLinks($request, $limit, $offset);

        $query = laptops::with('brands');
        $query = $query->skip($offset)->take($limit);

        $laptops = $query->get();

        $payload = [];

        foreach ($laptops as $laptop) {
            $payload[$laptop->id] = [
                'LaptopID' => $laptop->ID,
                'BrandId' => $laptop->Brand,
                'Price' => $laptop->price
            ];
        }

        $final_payload = [
            'totalCount' => $count,
            'limit' => $limit,
            'offset' => $offset,
            'links' => $links,
            'data' => $payload
        ];
        return $response->withStatus(200)->withJson($final_payload);
    }
    public function sorting ($request, $response, $args)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        $links = laptops::getLinks($request, $limit, $offset);
        $laptop_array = laptops::getSortKeys($request);

        $query = laptops::with('brands');
        $query = $query->skip($offset)->take($limit);

        foreach ($laptop_array as $column => $direction){
            $query->orderBy($column, $direction);
        }

        $laptops = $query->get();

        $payload = [];

        foreach ($laptops as $laptop) {
            $payload[$laptop->id] = [
                'LaptopID' => $laptop->ID,
                'BrandId' => $laptop->Brand,
                'Price' => $laptop->price
            ];
        }

        $final_payload = [
            'totalCount' => $count,
            'limit' => $limit,
            'offset' => $offset,
            'links' => $links,
            'data' => $payload
        ];
        return $response->withStatus(200)->withJson($final_payload);
    }

    public function search ($request, $response, $args)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        $term = array_key_exists('q', $params) ? $params['q'] : null;

        if (!is_null($term)) {
            $laptops = laptops::searchLaptop($term);
            $payload_final = [];
            foreach ($laptops as $_lap) {
                $payload_final[$_lap->id] = [

                    'LaptopID' => $_lap->ID,
                    'user_id' => $_lap->user_id,
                    'created_at' => $_lap->created_at,
                ];
            }
        } else {

        $links = laptops::getLinks($request, $limit, $offset);
        $laptop_array = laptops::getSortKeys($request);

        $query = laptops::with('brands');
        $query = $query->skip($offset)->take($limit);

        foreach ($laptop_array as $column => $direction) {
            $query->orderBy($column, $direction);
        }

        $laptops = $query->get();

        $payload = [];

        foreach ($laptops as $laptop) {
            $payload[$laptop->id] = [
                'LaptopID' => $laptop->ID,
                'BrandId' => $laptop->Brand,
                'Price' => $laptop->price
            ];
        }

        $final_payload = [
            'totalCount' => $count,
            'limit' => $limit,
            'offset' => $offset,
            'links' => $links,
            'data' => $payload
        ];

        }

        return $response->withStatus(200)->withJson($final_payload);
    }
**/
}
