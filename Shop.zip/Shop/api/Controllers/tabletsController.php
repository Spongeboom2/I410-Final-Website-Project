<?php


namespace Shop\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\tablets;

class tabletsController
{

    //list all  with pagination, sort, search by query features
    public function index(Request $request, Response $response, array $args)
    {
        $results = tablets::getTablet($request);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    //view id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['TabletID'];
        $results = tablets:: getTabletById($id);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Create
    public function create(Request $request, Response $response, array $args)
    {
        // Insert
        $tablet = tablets::createTablet($request);
        if ($tablet->id) {
            $results = [
                'status' => 'tablet created',
                'tablet_uri' => '/tablet/' . $tablet->id,
                'data' => $tablet
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update
    public function update(Request $request, Response $response, array $args)
    {
        // Insert
        $smart = smart_watches::updateTablet($request);
        if ($smart->id) {
            $results = [
                'status' => 'tablet created',
                'tablet_uri' => '/tablet/' . $smart->id,
                'data' => $smart
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('TabletID');
        tablets::deleteTablet($request);
        if (tablets::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "tablet '/tablets/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }
}

