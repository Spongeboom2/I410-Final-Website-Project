<?php


namespace Shop\Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\desktops;

class desktopsController
{

    //list all laptops with pagination, sort, search by query features
    public function index(Request $request, Response $response, array $args)
    {
        echo "laptop controller index";
        $results = desktops::getDesktops();
        print_r($results);
        $code = array_key_exists("status", $results) ? 500 : 200;
        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    //view a desktop by id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['DesktopID'];
        $results = desktops:: getDesktopById($id);
        $code = array_key_exists("status", $results) ? 500 : 200;

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Create a laptop
    public function create(Request $request, Response $response, array $args)
    {
        // Insert a new desktop
        $desktop = desktops::createDesktop($request);
        if ($desktop->id) {
            $results = [
                'status' => 'desktop created',
                'desktops_uri' => '/desktops/' . $desktop->id,
                'data' => $desktop
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update a desktop
    public function update(Request $request, Response $response, array $args)
    {
        // Insert a new laptop
        $laptop = desktops::updateDesktop($request);
        if ($laptop->id) {
            $results = [
                'status' => 'desktop created',
                'desktop_uri' => '/desktops/' . $laptop->id,
                'data' => $laptop
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete a laptop
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('id');
        desktops::deleteDesktop($request);
        if (desktops::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "Desktop '/desktops/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }
}
