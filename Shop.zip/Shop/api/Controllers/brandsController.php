<?php
namespace Shop\Controllers;

use Chatter\Models\Message;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Shop\Models\brands;
use Shop\Models\desktops;

class brandsController
{
//list all brands in database
    public function index(Request $request, Response $response, array $args)
    {
        $results = brands::getBrand();
        $code = array_key_exists('status', $results) ? 500 : 200;
        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

//get single brand by id
    public function view(Request $request, Response $response, array $args)
    {
        $id = $args['BrandID'];
        $results = brands::getBrandById($id);
        $code = array_key_exists('status', $results) ? 500 : 200;
        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    public function create(Request $request, Response $response, array $args)
    {
        // Insert a new brand
        $brands = brands::createBrand($request);
        if ($brands->id) {
            $results = [
                'status' => 'Brand created',
                'message_uri' => '/brands/' . $brands->id,
                'data' => $brands
            ];
            $code = 201;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Update a message
    public function update(Request $request, Response $response, array $args)
    {
        // Insert a new brand
        $brands = brands::updateBrand($request);
        if ($brands->id) {
            $results = [
                'status' => 'Brand updated',
                'brand_uri' => '/brands/' . $brands->id,
                'data' => $brands
            ];
            $code = 200;
        } else {
            $code = 500;
        }

        return $response->withJson($results, $code, JSON_PRETTY_PRINT);
    }

    // Delete a brand
    public function delete(Request $request, Response $response, array $args)
    {
        $id = $request->getAttribute('BrandID');
        brands::deleteBrand($request);
        if (brands::find($id)->exists) {
            return $response->withStatus(500);

        } else {
            $results = [
                'status' => "Brand '/brands/$id' has been deleted."
            ];
            return $response->withJson($results, 200, JSON_PRETTY_PRINT);
        }
    }
}

