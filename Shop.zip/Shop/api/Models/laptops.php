<?php
namespace Shop\Models;

use \Illuminate\Database\Eloquent\Model;

class laptops extends Model
{
    protected $tables = 'laptops';
    protected $primaryKey = 'LaptopID';


    public function brands(){
        return $this->Hasmany(brands::class, 'BrandID');
    }

    public static function getLaptop($request)
    {
        $laptops = laptops::all();

        $payload = [];

        // Calling laptops with Pagination, Search, and Sorting
        $laptopPSS = self::getLaptopPSS($request);
        return $laptopPSS;

//        if(!$laptopPSS) {
//            foreach ($laptopPSS as $laptop) {
//                $payload[$laptop->LaptopID] = [
//                    "LaptopID" => $laptop->LaptopID,
//                    "Brand" => $laptop->BrandID,
//                    "Price" => $laptop->Price,
//                    "model" => $laptop->Model,
//                    'warranty' => $laptop->Warranty
//                ];
//            }
//            return $payload;
//            print_r($payload);
//        }
    }


    public static function getLaptopById($id)
    {
        $laptops = new laptops();
        $_lap = $laptops->find($id);


        $payload[$_lap->laptopID] = [
            "LaptopID" => $_lap->LaptopID,
            "BrandID" => $_lap->BrandID,
            "Price" => $_lap->Price,
            "Warranty" => $_lap->Warranty,
            "Model" => $_lap->Model,
        ];
        return $payload;
    }

    public static function createLaptop($request)
    {
        $laptops = new laptops();

        $_laptop_id = $request->getParsedBodyParam('LaptopID');
        $_laptop = $request->getParsedBodyParam('LaptopName');
        $laptops->laptop_id = $_laptop_id;
        $laptops->laptop = $_laptop;
        $laptops->save();

        if ($laptops->id) {
            $payload = ['LaptopID' => $laptops->id,
                'laptops_uri' => '/laptops/' . $laptops->id];
        }
        return $payload;
    }

    public static function updateLaptop($request)
    {
        $id = $request->getAttribute('LaptopID');
        $laptops = laptops::findOrFail($id);

        $params = $request->getParsedBody();

        foreach ($params as $field => $value) {
            $laptops->$field = $value;
        }
        $laptops->save();

        if ($laptops->id) {
            $payload = ['LaptopID' => $laptops->LaptopID,
                "BrandID" => $laptops->BrandID,
                "Price" => $laptops->Price,
                "model"=> $laptops->Model,
                'warranty' => $laptops->Warranty,
                'laptops_uri' => '/laptops/' . $laptops->LaptopID
            ];
        }
        return $payload;
    }

    public static function deleteLaptop($request)
    {
        $id = $request->getAttribute('LaptopID');
        $brands = laptops::find($id);
        $brands->delete();

        if ($brands->exits) {
            return $request;
        }
        return $brands;
    }

 public static function getLaptopPSS ($request)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        // Does limit and offset exist
        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        //Getting laptop search Term
        $lapTerm = array_key_exists('q', $params) ? $params['q'] : null;

        if(!is_null($lapTerm)){
            $laptops = self::searchLaptop($lapTerm);
            return $laptops;
        }else {
            //Pagination
            $links = self::getLinks($request, $limit, $offset);
            //Sorting
            $laptop_key_array = self::getSortKeys($request);

            $query = self::with('brands');
            $query = $query->skip($offset)->take($limit);

            // Sort results by one or more colums
            foreach($laptop_key_array as $column => $direction){
                $query->orderBy($column, $direction);
            }

            $laptops = $query->get();

            $final_payload = [
                'totalCount' => $count,
                'limit' => $limit,
                'offset' => $offset,
                'links' => $links,
                'sort' => $laptop_key_array,
                'data' => $laptops
            ];
            return $final_payload;
        }
    }

    public static function getLinks($request, $limit, $offset){

        $count = self::count();

        $uri = $request->getUri();
        $base_url = $uri->getBaseUrl();
        $path = $uri->getPath();

        $links = array();
        $links[] = ['rel' => 'self', 'href' => $base_url . "/$path" . "?limit=$limit&offset=$offset"];
        $links[] = ['rel' => 'first', 'href' => $base_url . "/$path" . "?limit=$limit&offset=0"];

        if ($offset - $limit >= 0) {
            $links[] = ['rel' => 'prev', 'href' => $base_url . "/$path" . "?limit=$limit&offset=" . ($offset - $limit)];
        }

        if ($offset + $limit < $count) {
            $links[] = ['rel' => 'next', 'href' => $base_url . "/$path" . "?limit=$limit&offset=" . ($offset + $limit)];
        }

        $links[] = ['rel' => 'last', 'href' => $base_url . "/$path" . "?limit=$limit&offset=" . $limit * (ceil($count / $limit) - 1)];

        return $links;
    }

    public static function getSortKeys($request)
    {
        $sort_key_array = array();

        // Get querystring variables from url
        $params = $request->getQueryParams();

        if (array_key_exists('sort', $params)) {
            $sort = preg_replace('/^\[|\]$|\s+/', '', $params['sort']);
            $sort_keys = explode(',', $sort);
            foreach ($sort_keys as $sort_key) {
                $direction = 'asc';
                $column = $sort_key;
                if (strpos($sort_key, ':')) {
                    list($column, $direction) = explode(':', $sort_key);
                }
                $sort_key_array[$column] = $direction;
            }
        }

        return $sort_key_array;
    }

    public static function searchLaptop($terms)
    {
        if (is_numeric($terms)) {
            $query = self::where('id', "like", "%$terms%");
        } else {
            $query = self::where('body', 'like', "%$terms%")
                ->orWhere('created_at', 'like', "%$terms%")
                ->orWhere('updated_at', 'like', "%$terms%");
        }
        $results = $query->get();
        return $results;
    }

    //Sorting function
    /*
    public static function sorting ($request, $response)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        $links = laptops::getLinks($request, $limit, $offset);
        $laptop_array = laptops::getSortKeys($request);

        $query = laptops::with('brands');
        $query = $query->skip($offset)->take($limit);

        foreach ($laptop_array as $column => $direction){
            $query->orderBy($column, $direction);
        }

        $laptops = $query->get();

        $payload = [];

        foreach ($laptops as $laptop) {
            $payload[$laptop->id] = [
                'LaptopID' => $laptop->ID,
                'BrandId' => $laptop->Brand,
                'Price' => $laptop->price
            ];
        }

        $final_payload = [
            'totalCount' => $count,
            'limit' => $limit,
            'offset' => $offset,
            'links' => $links,
            'data' => $payload
        ];
        return $response->withStatus(200)->withJson($final_payload);
    }*/


    // Search function

   /* public function search ($request, $response, $args)
    {
        $count = laptops::count();

        $params = $request->getQueryParams();

        $limit = array_key_exists('limit', $params) ? (int)$params['limit'] : 10;
        $offset = array_key_exists('offset', $params) ? (int)$params['offset'] : 0;

        $term = array_key_exists('q', $params) ? $params['q'] : null;

        if (!is_null($term)) {
            $laptops = laptops::searchLaptop($term);
            $payload_final = [];
            foreach ($laptops as $_lap) {
                $payload_final[$_lap->id] = [

                    'LaptopID' => $_lap->ID,
                    'user_id' => $_lap->user_id,
                    'created_at' => $_lap->created_at,
                ];
            }
        } else {

            $links = laptops::getLinks($request, $limit, $offset);
            $laptop_array = laptops::getSortKeys($request);

            $query = laptops::with('brands');
            $query = $query->skip($offset)->take($limit);

            foreach ($laptop_array as $column => $direction) {
                $query->orderBy($column, $direction);
            }

            $laptops = $query->get();

            $payload = [];

            foreach ($laptops as $laptop) {
                $payload[$laptop->id] = [
                    'LaptopID' => $laptop->ID,
                    'BrandId' => $laptop->Brand,
                    'Price' => $laptop->price
                ];
            }

            $final_payload = [
                'totalCount' => $count,
                'limit' => $limit,
                'offset' => $offset,
                'links' => $links,
                'data' => $payload
            ];

        }
        return $response->withStatus(200)->withJson($final_payload);
    }*/
}