<?php
namespace Shop\Models;

use \Illuminate\Database\Eloquent\Model;

class smart_watches extends Model
{
    protected $tables = 'smart_watches';
    protected $primaryKey = 'WatchID';


    public function brands(){
        return $this->hasMany(brands::class, 'BrandID');
    }

    public static function getSmart($request)
    {
        $watches = smart_watches::all();

        $payload = [];

        foreach($watches as $watch){
            $payload[$watch->MobileID] = [
                "WatchID" => $watch->WatchID,
                "Brand" => $watch->BrandID,
                "Price" => $watch->Price,
                "model"=> $watch->Model,
                'warranty' => $watch->Warranty
            ];
        }
        return $payload;
    }


    public static function getSmartById($id)
    {
        $watches = new smart_watches();
        $_lap = $watches->find($id);

        $payload[$_lap->WatchID] = [
            "MobileID" => $_lap->WatchID,
            "BrandID" => $_lap->Brand,
            "Price" => $_lap->Price,
            "Warranty" => $_lap->Warranty,
            "Version" => $_lap->Version
        ];
        return $payload;
    }

    public static function createSmart($request)
    {
        $mobiles = new smart_watches();

        $_mobile_id = $request->getParsedBodyParam('WatchID');
        $_mobile = $request->getParsedBodyParam('WatchName');
        $mobiles->mobile_id = $_mobile_id;
        $mobiles->mobile = $_mobile;
        $mobiles->save();

        if ($mobiles->id) {
            $payload = ['WatchID' => $mobiles->id,
                'Watch_uri' => '/smart_watches/' . $mobiles->id];
        }
        return $payload;
    }

    public static function updateSmart($request)
    {
        $id = $request->getAttribute('WatchID');
        $mobiles = smart_watches::findOrFail($id);

        $params = $request->getParsedBody();

        foreach ($params as $field => $value) {
            $mobiles->$field = $value;
        }
        $mobiles->save();

        if ($mobiles->id) {
            $payload = [
                "WatchID" => $mobiles->WatchID,
                "BrandID" => $mobiles->Brand,
                "Price" => $mobiles->Price,
                "Warranty" => $mobiles->Warranty,
                "Version" => $mobiles->Version,
            ];
        }
        return $payload;
    }

    public static function deleteSmart($request)
    {
        $id = $request->getAttribute('WatchID');
        $mobiles = smart_watches::find($id);
        $mobiles->delete();

        if ($mobiles->exits) {
            return $request;
        }
        return $mobiles;
    }


}