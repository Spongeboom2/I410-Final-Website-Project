<?php


namespace Shop\Models;

use Illuminate\Database\Eloquent\Model;
use Firebase\JWT\JWT;

class User extends Model
{

    const JWT_KEY = 'my signature';
    const JWT_EXPIRE = 3600;
    // The table associated with this model
    protected $table = 'users';
    protected $primaryKey = 'id';
    public $timestamps = false;


    //get all users
    public static function getUsers()
    {
        $users = self::all();
        return $users;
    }

    //get a user by id
    public static function getUserById($id)
    {
        $user = self::findOrFail($id);
        return $user;
    }

    // Create a new user
    public static function createUser($request)
    {
        // Retrieve parameters from request body
        $params = $request->getParsedBody();

        // Create a new User instance
        $user = new User();

        // Set the user's attributes
        foreach ($params as $field => $value) {

            // Need to hash password
            if ($field == 'password') {
                $value = password_hash($value, PASSWORD_DEFAULT);
            }

            $user->$field = $value;
        }

        // Insert the user into the database
        $user->save();
        return $user;
    }

    // Update a user
    public static function updateUser($request)
    {
        // Retrieve parameters from request body
        $params = $request->getParsedBody();

        //Retrieve the user's id from url and then the user from the database
        $id = $request->getAttribute('id');
        $user = self::findOrFail($id);

        // Update attributes of the professor
        $user->email = $params['email'];
        $user->username = $params['username'];
        $user->password = password_hash($params['password'], PASSWORD_DEFAULT);
        $user->profile_icon = $params['profile_icon'];

        // Update the professor
        $user->save();
        return $user;
    }

    // Delete a user
    public static function deleteUser($id)
    {
        $user = self::findOrFail($id);
        return ($user->delete());
    }

    //User Authencation

    // Authenticate a user by username and password. Return the user.
    public static function authenticateUser($username, $password)
    {
        $user = self::where('username', $username)->first();
        if (!$user) {
            return false;
        }

        return password_verify($password, $user->password) ? $user : false;
    }


    public static function generateJWT($id)
    {
        // Data for payload
        $user = $user = self::findOrFail($id);
        if (!$user) {
            return false;
        }

        $key = self::JWT_KEY;
        $expiration = time() + self::JWT_EXPIRE;
        $issuer = 'mychatter-api.com';

        $token = [
            'iss' => $issuer,
            'exp' => $expiration,
            'isa' => time(),
            'data' => [
                'uid' => $id,
                'name' => $user->username,
                'email' => $user->email,
            ]
        ];
        // Generate and return a token
        return JWT::encode(
            $token,   // data to be encoded in the JWT
            $key,    // the signing key
            'HS256'   // algorithm used to sign the token; defaults to HS256
        );
    }

    // Verify a token
    public static function validateJWT($token)
    {
        $decoded = JWT::decode($token, self::JWT_KEY, array('HS256'));
        // print_r($decoded); exit;
        return $decoded;

    }


}