<?php
namespace Shop\Models;

use \Illuminate\Database\Eloquent\Model;

class desktops extends Model
{
    protected $tables = 'desktops';
    protected $primaryKey = 'DesktopID';


    public function brands(){
        return $this->hasMany(brands::class, 'BrandID');
    }



    public static function getDesktops()
    {
        $desktops = desktops::all();

        $payload = [];

        foreach($desktops as $desktop){
            $payload[$desktop->DesktopID] = [
                "DesktopID" => $desktop->DesktopID,
                "BrandID" => $desktop->BrandID,
                "Price" => $desktop->Price,
                "model"=> $desktop->model,
                'warranty' => $desktop->warranty,
            ];
        }
        return $payload;
    }


    public static function getDesktopById($id)
    {
        $desktops = new desktops();
        $_desk = $desktops->find($id);

        $payload[$_desk->desktopID] = [
            "DesktopID" => $_desk->DesktopID,
            "BrandID" => $_desk->BrandID,
            "Price" => $_desk->Price,
            "Warranty" => $_desk->warranty,
            "Model" => $_desk->model
        ];
        return $payload;
    }

    public static function createDesktop($request)
    {
        $desktops = new desktops();

        $_desktop_id = $request->getParsedBodyParam('DesktopID');
        $_desktop = $request->getParsedBodyParam('desktopName');
        $desktops->desktop_id = $_desktop_id;
        $desktops->desktop = $_desktop;
        $desktops->save();

        if ($desktops->id) {
            $payload = ['DesktopID' => $desktops->id,
                'desktops_uri' => '/desktops/' . $desktops->id];
        }
        return $payload;
    }

    public static function updatedesktop($request)
    {
        $id = $request->getAttribute('DesktopID');
        $desktops = desktops::findOrFail($id);

        $params = $request->getParsedBody();

        foreach ($params as $field => $value) {
            $desktops->$field = $value;
        }
        $desktops->save();

        if ($desktops->id) {
            $payload = ['DesktopID' => $desktops->DestkopID,
                'DesktopName' => $desktops->DesktopName,
                'desktops_uri' => '/desktops/' . $desktops->BrandID
            ];
        }
        return $payload;
    }

    public static function deletedesktop($request)
    {
        $id = $request->getAttribute('DesktopID');
        $brands = desktops::find($id);
        $brands->delete();

        if ($brands->exits) {
            return $request;
        }
        return $brands;
    }


}