<?php
namespace Shop\Models;

use Chatter\Models\Message;
use \Illuminate\Database\Eloquent\Model;

class brands extends Model
{
    protected $tables = 'brands';
    protected $primaryKey = 'BrandID';

    public function desktops(){
        return $this->BelongsTo(desktops::class, 'DesktopID');
    }

    public function laptops(){
        return $this->BelongsTo(laptops::class, 'LaptopID');
    }

    public function mobile_devices(){
        return $this->BelongsTo(mobile_devices::class, 'MobileID');
    }

    public function tablets(){
        return $this->BelongsTo(tablets::class, 'TabletID');
    }

    public function smart_watches(){
        return $this->BelongsTo(smart_watches::class, 'SmartID');
    }

    public static function getBrand(){

        $brands = brands::all();

        $payload = [];

        foreach($brands as $Brand){
            $payload[$Brand->BrandID] = [
                "BrandID" => $Brand->BrandID,
                "BrandName" => $Brand->BrandName,

            ];
        }
        return $payload;
    }

    public static function getBrandById($id){
        $brands = new brands();
        $_brand = $brands->find($id);

        $payload[$_brand->BrandID] = [
            "BrandID" => $_brand->BrandID,
            "BrandName" => $_brand->BrandName,

        ];
        return $payload;
    }

    public static function createBrand($request) {
        $params = $request->getParsedBody();

        //Creates a new message object
        $brands = new brands();

        foreach ($params as $field => $value) {
            $brands->$field = $value;
        }

        $brands->save();
        return $brands;
    }

    public static function updateBrand($request)
    {
        $params = $request->getParsedBody();
        $id = $request->getAttribute('BrandID');
        $brands = self::findOrFail($id);

        foreach ($params as $field => $value) {
            $brands->$field = $value;
        }
        $brands->save();
        return $brands;
    }


    //delete a message
    public static function deleteBrand($request)
    {
        $id = $request->getAttribute('BrandID');
        $brands = self::findOrFail($id);
        return($brands->delete());
    }
}