<?php
namespace Shop\Models;

use \Illuminate\Database\Eloquent\Model;

class mobile_devices extends Model
{
    protected $tables = 'mobile_devices';
    protected $primaryKey = 'MobileID';


    public function brands(){
        return $this->hasMany(brands::class, 'BrandID');
    }

    public static function getMobile($request)
    {
        $mobiles = mobile_devices::all();

        $payload = [];

        foreach($mobiles as $mobile){
            $payload[$mobile->MobileID] = [
                "MobileID" => $mobile->MobileID,
                "Brand" => $mobile->BrandID,
                "Price" => $mobile->Price,
                "model"=> $mobile->Model,
                'warranty' => $mobile->Warranty
            ];
        }
        return $payload;
    }


    public static function getMobileById($id)
    {
        $mobiles = new mobile_devices();
        $_lap = $mobiles->find($id);

        $payload[$_lap->MobileID] = [
            "MobileID" => $_lap->MobileID,
            "BrandID" => $_lap->Brand,
            "Price" => $_lap->Price,
            "Warranty" => $_lap->Warranty,
            "Version" => $_lap->Version
        ];
        return $payload;
    }

    public static function createMobile($request)
    {
        $mobiles = new mobile_devices();

        $_mobile_id = $request->getParsedBodyParam('MobileID');
        $_mobile = $request->getParsedBodyParam('MobileName');
        $mobiles->mobile_id = $_mobile_id;
        $mobiles->mobile = $_mobile;
        $mobiles->save();

        if ($mobiles->id) {
            $payload = ['MobileID' => $mobiles->id,
                'mobiles_uri' => '/mobiles/' . $mobiles->id];
        }
        return $payload;
    }

    public static function updateMobile($request)
    {
        $id = $request->getAttribute('MobileID');
        $mobiles = mobile_devices::findOrFail($id);

        $params = $request->getParsedBody();

        foreach ($params as $field => $value) {
            $mobiles->$field = $value;
        }
        $mobiles->save();

        if ($mobiles->id) {
            $payload = [
                "MobileID" => $mobiles->MobileID,
                "BrandID" => $mobiles->Brand,
                "Price" => $mobiles->Price,
                "Warranty" => $mobiles->Warranty,
                "Version" => $mobiles->Version,
            ];
        }
        return $payload;
    }

    public static function deleteMobile($request)
    {
        $id = $request->getAttribute('MobileID');
        $mobiles = mobile_devices::find($id);
        $mobiles->delete();

        if ($mobiles->exits) {
            return $request;
        }
        return $mobiles;
    }


}