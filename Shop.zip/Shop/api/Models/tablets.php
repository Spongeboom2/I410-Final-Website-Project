<?php
namespace Shop\Models;

use \Illuminate\Database\Eloquent\Model;

class tablets extends Model
{
protected $tables = 'tablets';
protected $primaryKey = 'TabletID';


public function brands(){
return $this->hasMany(brands::class, 'BrandID');
}

    public static function getTablet($request)
    {
        $tablets = tablets::all();

        $payload = [];

        foreach($tablets as $tablet){
            $payload[$tablet->TabletID] = [
                "TabletID" => $tablet->TabletID,
                "Brand" => $tablet->BrandID,
                "Price" => $tablet->Price,
                "model"=> $tablet->Model,
                'warranty' => $tablet->Warranty
            ];
        }
        return $payload;
    }


    public static function getTabletById($id)
    {
        $tablets = new tablets();
        $_tab = $tablets->find($id);

        $payload[$_tab->TabletID] = [
            "LaptopID" => $_tab->TabletID,
            "BrandID" => $_tab->BrandID,
            "Price" => $_tab->Price,
            "Warranty" => $_tab->Warranty,
            "Model" => $_tab->Model
        ];
        return $payload;
    }

    public static function createTablet($request)
    {
        $tablets = new tablets();

        $_tablet_id = $request->getParsedBodyParam('TabletID');
        $_tablet = $request->getParsedBodyParam('TabletName');
        $tablets->tablet_id = $_tablet_id;
        $tablets->tablet = $_tablet;
        $tablets->save();

        if ($tablets->id) {
            $payload = ['TabletID' => $tablets->id,
                'tablets_uri' => '/tablets/' . $tablets->id];
        }
        return $payload;
    }

    public static function updateTablet($request)
    {
        $id = $request->getAttribute('TabletID');
        $tablets = tablets::findOrFail($id);

        $params = $request->getParsedBody();

        foreach ($params as $field => $value) {
            $tablets->$field = $value;
        }
        $tablets->save();

        if ($tablets->id) {
            $payload = ['TabletID' => $tablets->TabletID,
                "BrandID" => $tablets->BrandID,
                "Price" => $tablets->Price,
                "model"=> $tablets->Model,
                'warranty' => $tablets->Warranty,
                'tablets_uri' => '/tablets/' . $tablets->LaptopID
            ];
        }
        return $payload;
    }

    public static function deleteTablet($request)
    {
        $id = $request->getAttribute('TabletID');
        $brands = tablets::find($id);
        $brands->delete();

        if ($brands->exits) {
            return $request;
        }
        return $brands;
    }


}